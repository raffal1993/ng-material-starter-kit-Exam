export interface CountryModel {
  name: string;
  id: string;
}
